#!/bin/bash
API_PATH=${1:-/admin/reports/v1/activity/users/all/applications/meet?maxResults=10}
echo "Quick test of psoxy-google-meet ..."

node /Users/erik/code/psoxy/tools/psoxy-test/cli-call.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -u "https://uetgsol5ciyaecnqeiibrluqfa0uazzq.lambda-url.us-east-1.on.aws$API_PATH"  -i "example@acme.com"

echo "Invoke this script with any of the following as arguments to test other endpoints:
	/admin/reports/v1/activity/users/all/applications/meet?maxResults=10"
