#!/bin/bash
API_PATH=${1:-/admin/directory/v1/users?customer=my_customer&maxResults=10}
echo "Quick test of psoxy-gdirectory ..."

node /Users/erik/code/psoxy/tools/psoxy-test/cli-call.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -u "https://u5mhat46oandoaavne4dcb3ksi0nmnao.lambda-url.us-east-1.on.aws$API_PATH"  -i "admin@acme.com"

echo "Invoke this script with any of the following as arguments to test other endpoints:
	/admin/directory/v1/users?customer=my_customer&maxResults=10
	/admin/directory/v1/groups?customer=my_customer&maxResults=10
	/admin/directory/v1/customer/my_customer/domains
	/admin/directory/v1/customer/my_customer/roles?maxResults=10
	/admin/directory/v1/customer/my_customer/roleassignments?maxResults=10"
