#!/bin/bash
API_PATH=${1:-/drive/v2/files}
echo "Quick test of psoxy-gdrive ..."

node /Users/erik/code/psoxy/tools/psoxy-test/cli-call.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -u "https://ncblvuaades5b46j6crejvmqeu0rgxgc.lambda-url.us-east-1.on.aws$API_PATH"  -i "example@acme.com"

echo "Invoke this script with any of the following as arguments to test other endpoints:
	/drive/v2/files
	/drive/v3/files"
