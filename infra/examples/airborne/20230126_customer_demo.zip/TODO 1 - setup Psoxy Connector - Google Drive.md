Complete the following steps via the Google Workspace Admin console:
   1. Visit https://admin.google.com/ and navigate to Security --> API Controls, then find "Manage
      Domain Wide Delegation". Click "Add new"
   2. Copy and paste client ID `117365161727178613792` into the "Client ID" input in the popup.
   3. Copy and paste the following OAuth 2.0 scope string into the "Scopes" input:
```
https://www.googleapis.com/auth/drive.metadata.readonly
```
   4. Authorize it. With this, your psoxy instance should be able to authenticate with Google as
     `psoxy-gdrive` and request data from Google as authorized by the OAuth
      scopes you granted.

