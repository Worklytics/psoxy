Complete the following steps in Worklytics AFTER you have deployed the Psoxy instance for your connection:

  1. Ensure you're authenticated with Worklytics. Either sign-in at `https://app.worklytics.co` with
     your organization's SSO provider *or* request OTP link from your Worklytics support team.
  2. Visit `https://intl.worklytics.co/analytics/connect/gdirectory-psoxy/settings?PROXY_DEPLOYMENT_KIND=AWS&PROXY_AWS_REGION=us-east-1&PROXY_AWS_ROLE_ARN=arn%3Aaws%3Aiam%3A%3A962428643465%3Arole%2FPsoxyCaller&PROXY_ENDPOINT=https%3A%2F%2Fu5mhat46oandoaavne4dcb3ksi0nmnao.lambda-url.us-east-1.on.aws%2F`.

  3. Review any additional settings that connector supports, adjusting values as you see fit, then
     click "Connect".

Alternatively, you may follow the manual instructions below:
  1. Visit https://intl.worklytics.co/analytics/integrations (or login into Worklytics, and navigate to
     Manage --> Data Connections)
  2. Click on the 'Add new connection' in the upper right.
  3. Find the connector named "Google Directory via Psoxy" and click 'Connect'.
      - If presented with a further screen with several options, choose the 'via Psoxy' one.
  4. Review instructions and click 'Connect' again.
  5. Select `AWS` for "Proxy Instance Type".

  6. Review any additional settings that connector supports, adjusting values as you see fit, then
     click "Connect".



Worklytics will attempt some basic health checks to ensure your Psoxy instance is reachable and
configured correctly. If this fails, contact support@worklytics.co for guidance.

