#!/bin/bash
API_PATH=${1:-/calendar/v3/calendars/primary}
echo "Quick test of psoxy-gcal ..."

node /Users/erik/code/psoxy/tools/psoxy-test/cli-call.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -u "https://bjihkekrek5h6wrsezf226bijm0hatyb.lambda-url.us-east-1.on.aws$API_PATH"  -i "example@acme.com"

echo "Invoke this script with any of the following as arguments to test other endpoints:
	/calendar/v3/calendars/primary
	/calendar/v3/users/me/settings
	/calendar/v3/calendars/primary/events?maxResults=10"
