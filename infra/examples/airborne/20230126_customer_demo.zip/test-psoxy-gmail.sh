#!/bin/bash
API_PATH=${1:-/gmail/v1/users/me/messages?maxResults=10}
echo "Quick test of psoxy-gmail ..."

node /Users/erik/code/psoxy/tools/psoxy-test/cli-call.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -u "https://3sbmhqkttfvzoxn5pqkvlrzt3u0dlwej.lambda-url.us-east-1.on.aws$API_PATH"  -i "example@acme.com"

echo "Invoke this script with any of the following as arguments to test other endpoints:
	/gmail/v1/users/me/messages?maxResults=10"
