#!/bin/bash
API_PATH=${1:-/v2/users}
echo "Quick test of psoxy-zoom ..."

node /Users/erik/code/psoxy/tools/psoxy-test/cli-call.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -u "https://bxe7kqp2o34dyn4rlofzlzhsrm0uwgqf.lambda-url.us-east-1.on.aws$API_PATH" 

echo "Invoke this script with any of the following as arguments to test other endpoints:
	/v2/users
	/v2/users/{USER_ID}/meetings
	/v2/past_meetings/{MEETING_ID}
	/v2/past_meetings/{MEETING_ID}/instances
	/v2/past_meetings/{MEETING_ID}/participants
	/v2/report/users/{userId}/meetings
	/v2/report/meetings/{meetingId}
	/v2/report/meetings/{meetingId}/participants"
