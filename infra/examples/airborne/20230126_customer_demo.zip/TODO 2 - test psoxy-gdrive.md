
## Testing psoxy-gdrive

Review the deployed function in AWS console:

- https://console.aws.amazon.com/lambda/home?region=us-east-1#/functions/psoxy-gdrive?tab=monitoring

We provide some Node.js scripts to easily validate the deployment. To be able
to run the test commands below, you need Node.js (>=16) and npm (v >=8)
installed. Then, ensure all dependencies are installed by running:

```shell
npm --prefix /Users/erik/code/psoxy/tools/psoxy-test install
```

### Make "test calls"

Based on your configuration, these are some example test calls you can try (YMMV):

```shell
node /Users/erik/code/psoxy/tools/psoxy-test/cli-call.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -u "https://ncblvuaades5b46j6crejvmqeu0rgxgc.lambda-url.us-east-1.on.aws/drive/v2/files" -i "example@acme.com"
node /Users/erik/code/psoxy/tools/psoxy-test/cli-call.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -u "https://ncblvuaades5b46j6crejvmqeu0rgxgc.lambda-url.us-east-1.on.aws/drive/v3/files" -i "example@acme.com"
```

Feel free to try the above calls, and reference to the source's API docs for other parameters /
endpoints to experiment with. If you spot any additional fields you believe should be
redacted/pseudonymized, feel free to modify the rules in your local repo and re-deploy OR configure
a RULES variable in the source.

### Check logs (AWS CloudWatch)

Based on your configuration, the following command allows you to inspect the
logs of your Psoxy deployment:

```shell
node /Users/erik/code/psoxy/tools/psoxy-test/cli-logs.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -re "us-east-1" -l "/aws/lambda/psoxy-gdrive"
```

---

Please, check the documentation of our [Psoxy Testing tools](/Users/erik/code/psoxy/tools/psoxy-test/README.md)
for a detailed description of all the different options.

Contact support@worklytics.co for assistance modifying the rules as needed.

