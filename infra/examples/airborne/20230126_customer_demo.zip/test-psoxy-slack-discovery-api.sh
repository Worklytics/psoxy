#!/bin/bash
API_PATH=${1:-/api/discovery.enterprise.info}
echo "Quick test of psoxy-slack-discovery-api ..."

node /Users/erik/code/psoxy/tools/psoxy-test/cli-call.js -r "arn:aws:iam::962428643465:role/InfraAdmin" -u "https://2wo4dqtac2crpv4bjt6dadjmbi0jjdeq.lambda-url.us-east-1.on.aws$API_PATH" 

echo "Invoke this script with any of the following as arguments to test other endpoints:
	/api/discovery.enterprise.info
	/api/discovery.conversations.list
	/api/discovery.conversations.history?channel={CHANNEL_ID}&limit=10
	/api/discovery.users.list"
