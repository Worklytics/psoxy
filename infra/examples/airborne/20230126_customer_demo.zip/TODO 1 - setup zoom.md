# TODO - Create User-Managed Token for zoom

Follow the following steps:

## Zoom Setup
Zoom connector through Psoxy requires a custom managed app on the Zoom Marketplace (in development
mode, no need to publish).
1. Go to https://marketplace.zoom.us/develop/create and create an app of type "Server to Server OAuth"
2. After creation it will show the App Credentials. Share them with the AWS/GCP administrator, the
following secret values must be filled in the Secret Manager for the Proxy with the appropriate values:
- `PSOXY_ZOOM_CLIENT_ID`
- `PSOXY_ZOOM_ACCOUNT_ID`
- `PSOXY_ZOOM_CLIENT_SECRET`
Anytime the *client secret* is regenerated it needs to be updated in the Proxy too.
3. Fill the information section
4. Fill the scopes section, enabling the following:
- Users / View all user information /user:read:admin
  - To be able to gather information about the zoom users
- Meetings / View all user meetings /meeting:read:admin
  - Allows us to list all user meeting
- Report / View report data /report:read:admin
  - Last 6 months view for user meetings
5. Activate the app


## Populate the token for PSOXY_ZOOM_CLIENT_SECRET in AWS Systems Manager Parameter Store.

### Using AWS cli

YMMV.
```shell
aws ssm put-parameter \
--region us-east-1 \
--name "PSOXY_ZOOM_CLIENT_SECRET" \
--type "SecureString " \
--value "YOUR_VALUE_HERE" \
--overwrite
```

from macOS clipboard
```shell
pbpaste | aws ssm put-parameter \
--region us-east-1 \
--name "PSOXY_ZOOM_CLIENT_SECRET" \
--type "SecureString " \
--value=- \
--overwrite
```

reference: https://cloud.google.com/sdk/gcloud/reference/secrets/versions/add

### AWS  Console

1. Visit

https://us-east-1.console.aws.amazon.com/systems-manager/parameters/PSOXY_ZOOM_CLIENT_SECRET/description?region=us-east-1&tab=Table

2. Click "Edit"; paste your value in the 'Value' field and click 'Save changes'.


## Populate the token for PSOXY_ZOOM_CLIENT_ID in AWS Systems Manager Parameter Store.

### Using AWS cli

YMMV.
```shell
aws ssm put-parameter \
--region us-east-1 \
--name "PSOXY_ZOOM_CLIENT_ID" \
--type "SecureString " \
--value "YOUR_VALUE_HERE" \
--overwrite
```

from macOS clipboard
```shell
pbpaste | aws ssm put-parameter \
--region us-east-1 \
--name "PSOXY_ZOOM_CLIENT_ID" \
--type "SecureString " \
--value=- \
--overwrite
```

reference: https://cloud.google.com/sdk/gcloud/reference/secrets/versions/add

### AWS  Console

1. Visit

https://us-east-1.console.aws.amazon.com/systems-manager/parameters/PSOXY_ZOOM_CLIENT_ID/description?region=us-east-1&tab=Table

2. Click "Edit"; paste your value in the 'Value' field and click 'Save changes'.


## Populate the token for PSOXY_ZOOM_ACCOUNT_ID in AWS Systems Manager Parameter Store.

### Using AWS cli

YMMV.
```shell
aws ssm put-parameter \
--region us-east-1 \
--name "PSOXY_ZOOM_ACCOUNT_ID" \
--type "SecureString " \
--value "YOUR_VALUE_HERE" \
--overwrite
```

from macOS clipboard
```shell
pbpaste | aws ssm put-parameter \
--region us-east-1 \
--name "PSOXY_ZOOM_ACCOUNT_ID" \
--type "SecureString " \
--value=- \
--overwrite
```

reference: https://cloud.google.com/sdk/gcloud/reference/secrets/versions/add

### AWS  Console

1. Visit

https://us-east-1.console.aws.amazon.com/systems-manager/parameters/PSOXY_ZOOM_ACCOUNT_ID/description?region=us-east-1&tab=Table

2. Click "Edit"; paste your value in the 'Value' field and click 'Save changes'.


## Populate the token for PSOXY_ZOOM_ACCESS_TOKEN in AWS Systems Manager Parameter Store.

### Using AWS cli

YMMV.
```shell
aws ssm put-parameter \
--region us-east-1 \
--name "PSOXY_ZOOM_ACCESS_TOKEN" \
--type "SecureString " \
--value "YOUR_VALUE_HERE" \
--overwrite
```

from macOS clipboard
```shell
pbpaste | aws ssm put-parameter \
--region us-east-1 \
--name "PSOXY_ZOOM_ACCESS_TOKEN" \
--type "SecureString " \
--value=- \
--overwrite
```

reference: https://cloud.google.com/sdk/gcloud/reference/secrets/versions/add

### AWS  Console

1. Visit

https://us-east-1.console.aws.amazon.com/systems-manager/parameters/PSOXY_ZOOM_ACCESS_TOKEN/description?region=us-east-1&tab=Table

2. Click "Edit"; paste your value in the 'Value' field and click 'Save changes'.


